INSERT INTO sala_aula.dbo.CURSO (ID, NOME) VALUES (3, 'ADS');
INSERT INTO sala_aula.dbo.CURSO (ID, NOME) VALUES (2, 'SI');